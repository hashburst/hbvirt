package main

import (
    "bytes"
    "fmt"
    "html/template"
    "log"
    "net/http"
    "os/exec"
    "runtime"
)

func main() {
    // Configura il percorso per il template HTML
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        renderTemplate(w, "index.html")
    })

    // Avvio del server web sulla porta 8080
    log.Println("Server in esecuzione su http://localhost:8080")
    err := http.ListenAndServe(":8080", nil)
    if err != nil {
        log.Fatalf("Errore nell'avvio del server: %v", err)
    }
}

// Funzione per caricare e renderizzare il template HTML
func renderTemplate(w http.ResponseWriter, tmpl string) {
    tmplPath := fmt.Sprintf("templates/%s", tmpl)
    t, err := template.ParseFiles(tmplPath)
    if err != nil {
        http.Error(w, "Errore nel caricamento del template", http.StatusInternalServerError)
        log.Printf("Errore nel caricamento del template: %v", err)
        return
    }
    err = t.Execute(w, nil)
    if err != nil {
        http.Error(w, "Errore nel rendering del template", http.StatusInternalServerError)
        log.Printf("Errore nel rendering del template: %v", err)
    }
}

// Funzione per eseguire un test di rete con ping
func testNetworkSpeed() error {
    var cmd *exec.Cmd
    if runtime.GOOS == "windows" {
        cmd = exec.Command("cmd", "/C", "ping", "8.8.8.8", "-n", "10")
    } else {
        cmd = exec.Command("ping", "-c", "10", "8.8.8.8")
    }

    var out bytes.Buffer
    cmd.Stdout = &out
    err := cmd.Run()
    if err != nil {
        return fmt.Errorf("errore nel test di rete: %v", err)
    }

    output := out.String()
    fmt.Println("Output del test di rete:\n", output)

    // Analizza il risultato del test di rete per ottenere il tempo di risposta medio
    var avgLatency float64
    var count int
    if runtime.GOOS == "windows" {
        // Parsing per Windows
        lines := bytes.Split(out.Bytes(), []byte{'\n'})
        for _, line := range lines {
            if bytes.Contains(line, []byte("Average")) {
                var avgStr string
                _, err := fmt.Sscanf(string(line), "Approximate round trip times in milli-seconds:\n    Minimum = %*s\n    Maximum = %*s\n    Average = %s", &avgStr)
                if err == nil {
                    fmt.Sscanf(avgStr, "%f", &avgLatency)
                    count++
                }
                break
            }
        }
    } else {
        // Parsing per Linux/Mac
        lines := bytes.Split(out.Bytes(), []byte{'\n'})
        for _, line := range lines {
            if bytes.HasPrefix(line, []byte("rtt min/avg/max/mdev")) {
                var min, avg, max, mdev float64
                _, err := fmt.Sscanf(string(line), "rtt min/avg/max/mdev = %f/%f/%f/%f ms", &min, &avg, &max, &mdev)
                if err == nil {
                    avgLatency = avg
                    count++
                }
                break
            }
        }
    }

    if count > 0 {
        fmt.Printf("Tempo di risposta medio: %.2f ms\n", avgLatency)
    } else {
        fmt.Println("Impossibile calcolare il tempo di risposta medio.")
    }

    return nil
}
