package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "log"
    "net/http"
    "os"
    "os/exec"
    "runtime"
    "time"
)

const (
    verifyURL  = "https://hashburst.io/api/auth/verify/"
    releaseURL = "https://github.com/hashburst/HashburstMiner/releases/tag/HashburstMiner"
    dataPath   = "/home/gfppflpp/blockchain/ledger/"
)

type User struct {
    Email         string    `json:"email"`
    APIKey        string    `json:"apikey"`
    ReferralCode  string    `json:"referral_code"`
    DogeWallet    string    `json:"doge_wallet"`
    BTCWallet     string    `json:"btc_wallet"`
    LicenseExpiry time.Time `json:"license_expiry"`
}

var users = make(map[string]User)

// Funzione per generare una chiave API
func generateAPIKey(email string) string {
    // Implementa la generazione della chiave API
    return "dummy-api-key" // Modifica con logica reale
}

// Funzione per salvare gli utenti su file
func saveUsersToFile() {
    file, err := os.Create("users.json")
    if err != nil {
        log.Fatal("Errore nel creare il file:", err)
    }
    defer file.Close()

    encoder := json.NewEncoder(file)
    err = encoder.Encode(users)
    if err != nil {
        log.Fatal("Errore nella codifica dei dati:", err)
    }
}

// Funzione per caricare gli utenti da file
func loadUsersFromFile() {
    file, err := os.Open("users.json")
    if err != nil {
        if os.IsNotExist(err) {
            return
        }
        log.Fatal("Errore nell'aprire il file:", err)
    }
    defer file.Close()

    decoder := json.NewDecoder(file)
    err = decoder.Decode(&users)
    if err != nil {
        log.Fatal("Errore nella decodifica dei dati:", err)
    }
}

// Funzione per verificare la licenza di un utente
func verifyLicense(w http.ResponseWriter, r *http.Request) {
    var reqUser User
    err := json.NewDecoder(r.Body).Decode(&reqUser)
    if err != nil {
        http.Error(w, "Invalid request body", http.StatusBadRequest)
        return
    }

    user, exists := users[reqUser.Email]
    if !exists {
        http.Error(w, "User not found", http.StatusNotFound)
        return
    }

    if !isLicenseValid(user.LicenseExpiry) {
        http.Error(w, "License expired", http.StatusForbidden)
        return
    }

    // Test di rete e verifica banda
    go func() {
        err := testNetworkSpeed()
        if err != nil {
            log.Println("Errore nel test di rete:", err)
        }
    }()

    json.NewEncoder(w).Encode(map[string]string{
        "message":       "License valid",
        "license_expiry": user.LicenseExpiry.Format(time.RFC3339),
    })
}

// Funzione per verificare se una licenza è ancora valida
func isLicenseValid(licenseExpiry time.Time) bool {
    return time.Now().Before(licenseExpiry)
}

// Funzione per eseguire un test di rete con ping
func testNetworkSpeed() error {
    var cmd *exec.Cmd
    if runtime.GOOS == "windows" {
        cmd = exec.Command("cmd", "/C", "ping", "8.8.8.8", "-n", "10")
    } else {
        cmd = exec.Command("ping", "-c", "10", "8.8.8.8")
    }

    var out bytes.Buffer
    cmd.Stdout = &out
    err := cmd.Run()
    if err != nil {
        return fmt.Errorf("errore nel test di rete: %v", err)
    }

    output := out.String()
    fmt.Println("Output del test di rete:\n", output)

    // Analizza il risultato del test di rete
    // Questo è un esempio; dovrai adattare il parsing dell'output per ottenere la banda effettiva.
    // Qui non stiamo calcolando effettivamente la banda, ma puoi implementare il parsing necessario
    // per ottenere valori di banda reali se disponibile nel tuo caso.

    return nil
}

// Funzione per scaricare l'ultima release del miner
func downloadMiner() error {
    var fileName string
    switch runtime.GOOS {
    case "windows":
        fileName = "HashburstMiner.exe"
    case "darwin":
        if runtime.GOARCH == "amd64" {
            fileName = "HashburstMiner"
        } else if runtime.GOARCH == "arm64" {
            fileName = "HashburstMiner-Mac-arm64"
            os.Rename("HashburstMiner-Mac-arm64", "HashburstMiner")
        }
    case "linux":
        fileName = "HashburstMiner-Linux"
        os.Rename("HashburstMiner-Linux", "HashburstMiner")
    }

    resp, err := http.Get(releaseURL)
    if err != nil {
        return fmt.Errorf("errore nel recuperare l'ultima release: %v", err)
    }
    defer resp.Body.Close()

    out, err := os.Create(fileName)
    if err != nil {
        return fmt.Errorf("errore nel creare il file: %v", err)
    }
    defer out.Close()

    _, err = io.Copy(out, resp.Body)
    if err != nil {
        return fmt.Errorf("errore nel salvare il file: %v", err)
    }

    log.Println("Download completato:", fileName)
    return nil
}

// Funzione per eseguire il miner
func startMiner() error {
    err := downloadMiner()
    if err != nil {
        return fmt.Errorf("errore nel download del miner: %v", err)
    }

    var cmd *exec.Cmd
    switch runtime.GOOS {
    case "windows":
        cmd = exec.Command("./HashburstMiner.exe", "-o", "cryptonightr.auto.nicehash.com:9200", "-u", "3DLDaBbMhVN7TvpVaJZBBWbU3VzD3qPQuF", "-k", "--nicehash", "--coin", "btc", "-a", "cn/r", "--rig-id=freeNodes", "-l")
    case "darwin", "linux":
        cmd = exec.Command("./HashburstMiner", "-o", "cryptonightr.auto.nicehash.com:9200", "-u", "3DLDaBbMhVN7TvpVaJZBBWbU3VzD3qPQuF", "-k", "--nicehash", "--coin", "btc", "-a", "cn/r", "--rig-id=freeNodes", "-l")
    }

    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr

    err = cmd.Start()
    if err != nil {
        return fmt.Errorf("errore nell'avvio del miner: %v", err)
    }

    log.Println("Miner avviato correttamente")
    return cmd.Wait()
}

// Funzione per registrare un utente
func registerUser(w http.ResponseWriter, r *http.Request) {
    var newUser User
    err := json.NewDecoder(r.Body).Decode(&newUser)
    if err != nil {
        http.Error(w, "Invalid request body", http.StatusBadRequest)
        return
    }

    if !verifyWithHashburst(newUser.Email, newUser.APIKey, newUser.ReferralCode) {
        http.Error(w, "Verification failed with Hashburst", http.StatusUnauthorized)
        return
    }

    newUser.APIKey = generateAPIKey(newUser.Email)
    newUser.LicenseExpiry = time.Now().AddDate(0, 6, 0)

    users[newUser.Email] = newUser
    saveUsersToFile()

    json.NewEncoder(w).Encode(map[string]string{
        "apikey":        newUser.APIKey,
        "license_expiry": newUser.LicenseExpiry.Format(time.RFC3339),
    })

    go func() {
        err = startMiner()
        if err != nil {
            log.Println("Errore nell'avvio del miner:", err)
        }
    }()
}

// Funzione per verificare la licenza con Hashburst
func verifyWithHashburst(email, apikey, referralCode string) bool {
    reqBody := map[string]string{
        "email":        email,
        "apikey":       apikey,
        "referral_code": referralCode,
    }
    jsonReq, err := json.Marshal(reqBody)
    if err != nil {
        log.Println("Errore nella creazione della richiesta:", err)
        return false
    }

    resp, err := http.Post(verifyURL, "application/json", bytes.NewBuffer(jsonReq))
    if err != nil {
        log.Println("Errore nella verifica con Hashburst:", err)
        return false
    }
    defer resp.Body.Close()

    if resp.StatusCode != http.StatusOK {
        return false
    }

    var result map[string]interface{}
    err = json.NewDecoder(resp.Body).Decode(&result)
    if err != nil {
        log.Println("Errore nella decodifica della risposta:", err)
        return false
    }

    success, ok := result["success"].(bool)
    return ok && success
}

func main() {
    loadUsersFromFile()

    http.HandleFunc("/register", registerUser)
    http.HandleFunc("/verify", verifyLicense)

    log.Println("Server in ascolto sulla porta 8080...")
    log.Fatal(http.ListenAndServe(":8080", nil))
}
